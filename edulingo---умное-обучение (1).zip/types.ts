
export type Grade = 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11;
export type ThemeType = 'light' | 'dark' | 'ocean' | 'sunset';

export interface DictionaryTerm {
  term: string;
  definition: string;
}

export interface UserProfile {
  name: string;
  grade: Grade;
  xp: number;
  streak: number;
  unlockedBadges: string[];
  theme: ThemeType;
  subjectLevels: Record<string, number>; // Уровень сложности для каждого предмета
  vocabulary: DictionaryTerm[];         // Список изученных терминов
  totalLessons: number;                 // Общее кол-во пройденных уроков
}

export interface Question {
  id: string;
  text: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export interface Lesson {
  title: string;
  subject: string;
  questions: Question[];
  keyTerms: DictionaryTerm[]; // Новые термины из этого урока
}

export interface Subject {
  id: string;
  name: string;
  icon: string;
  color: string;
  minGrade: number;
  maxGrade: number;
}
