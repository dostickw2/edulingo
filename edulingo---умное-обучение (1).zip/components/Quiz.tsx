import React, { useState } from 'react';
import { Lesson, Question, ThemeType } from '../types';
import { geminiService } from '../services/geminiService';

interface QuizProps {
  lesson: Lesson;
  onFinish: (score: number) => void;
  onClose: () => void;
  theme: ThemeType;
}

const Quiz: React.FC<QuizProps> = ({ lesson, onFinish, onClose, theme }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [score, setScore] = useState(0);
  
  // Состояния для подробного объяснения
  const [isDetailOpen, setIsDetailOpen] = useState(false);
  const [detailLoading, setDetailLoading] = useState(false);
  const [detailedData, setDetailedData] = useState<{ detail: string, example: string } | null>(null);

  const isDark = theme !== 'light';
  const currentQuestion = lesson.questions[currentIndex];
  const progress = ((currentIndex + 1) / lesson.questions.length) * 100;

  const handleAnswer = () => {
    if (selectedOption === null) return;
    setIsAnswered(true);
    if (selectedOption === currentQuestion.correctIndex) {
      setScore(s => s + 10);
    }
  };

  const handleOpenDetail = async () => {
    if (!isAnswered || selectedOption === null) return;
    setIsDetailOpen(true);
    setDetailLoading(true);
    try {
      const data = await geminiService.getDetailedExplanation(
        currentQuestion, 
        currentQuestion.options[selectedOption],
        selectedOption === currentQuestion.correctIndex
      );
      setDetailedData(data);
    } catch (err) {
      console.error(err);
    } finally {
      setDetailLoading(false);
    }
  };

  const handleNext = () => {
    if (currentIndex < lesson.questions.length - 1) {
      setCurrentIndex(currentIndex + 1);
      setSelectedOption(null);
      setIsAnswered(false);
      setDetailedData(null);
      setIsDetailOpen(false);
    } else {
      onFinish(score + (selectedOption === currentQuestion.correctIndex ? 10 : 0));
    }
  };

  const isCorrect = selectedOption === currentQuestion.correctIndex;

  const bgClass = isDark ? (theme === 'dark' ? 'bg-[#131f24]' : theme === 'ocean' ? 'bg-[#0a2e36]' : 'bg-[#2a1122]') : 'bg-white';
  const textClass = isDark ? 'text-white' : 'text-gray-800';

  return (
    <div className={`fixed inset-0 ${bgClass} ${textClass} z-50 flex flex-col theme-transition overflow-hidden`}>
      <div className="max-w-4xl w-full mx-auto flex-1 flex flex-col p-6">
        {/* Header */}
        <div className="flex items-center gap-6 mb-8 lg:mb-12">
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-4xl font-bold transition-transform hover:scale-110">×</button>
          <div className="flex-1 h-4 bg-gray-200/20 rounded-full overflow-hidden">
            <div 
              className="h-full bg-[#1e3a8a] transition-all duration-500 shadow-[0_0_15px_#1e3a8a]" 
              style={{ width: `${progress}%` }} 
            />
          </div>
          <div className="font-black text-orange-500 flex items-center gap-2 text-xl">
            🔥 {score}
          </div>
        </div>

        {/* Question Content */}
        <div className="flex-1 flex flex-col items-center justify-center">
          <div className="w-full max-w-2xl text-center mb-10">
             <h2 className="text-2xl lg:text-3xl font-black leading-tight">{currentQuestion.text}</h2>
          </div>
          
          {/* Answers Grid 2x2 */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 w-full max-w-3xl">
            {currentQuestion.options.map((option, idx) => (
              <button
                key={idx}
                disabled={isAnswered}
                onClick={() => setSelectedOption(idx)}
                className={`w-full p-6 text-left rounded-3xl border-2 font-black transition-all text-lg duo-button-shadow ${
                  selectedOption === idx
                    ? isAnswered 
                      ? isCorrect 
                        ? 'border-[#1e3a8a] bg-[#1e3a8a]/20 text-[#1e3a8a]'
                        : 'border-[#ff4b4b] bg-[#ff4b4b]/20 text-[#ff4b4b]'
                      : isDark ? 'border-[#77d0ff] bg-[#77d0ff]/20 text-[#77d0ff]' : 'border-[#84d8ff] bg-[#ddf4ff] text-[#1899d6]'
                    : isDark ? 'border-[#37464f] hover:bg-white/5' : 'border-gray-200 hover:bg-gray-50'
                }`}
              >
                <span className="inline-block w-8 h-8 mr-3 rounded-xl border-2 border-inherit text-center leading-7 text-sm">
                  {idx + 1}
                </span>
                {option}
              </button>
            ))}
          </div>
        </div>

        {/* Footer Area - Rounded-t-3xl */}
        <div className={`fixed bottom-0 left-0 right-0 p-8 lg:p-10 transition-all rounded-t-[3rem] shadow-[0_-10px_40px_rgba(0,0,0,0.1)] ${
          isAnswered 
            ? isCorrect ? 'bg-[#dbeafe]' : 'bg-[#ffdfe0]'
            : isDark ? 'bg-[#1a2b33]' : 'bg-white border-t-2 border-gray-100'
        }`}>
          <div className="max-w-4xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-6">
            {isAnswered ? (
              <div className="flex items-center gap-6 animate-slideUp cursor-pointer group" onClick={handleOpenDetail}>
                <div className={`w-20 h-20 rounded-3xl flex items-center justify-center text-white text-4xl shadow-lg transition-transform group-hover:scale-105 ${isCorrect ? 'bg-[#1e3a8a]' : 'bg-[#ff4b4b]'}`}>
                  {isCorrect ? '✓' : '!'}
                </div>
                <div className="flex-1">
                  <h3 className={`font-black text-2xl mb-1 ${isCorrect ? 'text-[#1e3a8a]' : 'text-[#ee2a2a]'}`}>
                    {isCorrect ? 'Отлично!' : 'Почти получилось!'}
                  </h3>
                  <p className={`text-sm font-bold leading-snug underline decoration-dotted ${isCorrect ? 'text-[#1e3a8a]/70' : 'text-[#ee2a2a]/70'}`}>
                    {currentQuestion.explanation} (Нажми для подробностей)
                  </p>
                </div>
              </div>
            ) : (
              <div className="hidden sm:block text-gray-400 font-bold italic">
                Выбери правильный вариант и нажми проверить!
              </div>
            )}
            
            <button
              onClick={isAnswered ? handleNext : handleAnswer}
              disabled={selectedOption === null}
              className={`w-full sm:w-auto px-16 py-5 rounded-3xl font-black uppercase tracking-widest transition-all duo-button-shadow text-xl ${
                selectedOption === null
                  ? 'bg-gray-200 text-gray-400 cursor-not-allowed'
                  : isAnswered
                    ? isCorrect ? 'bg-[#1e3a8a] text-white hover:bg-[#1e40af]' : 'bg-[#ff4b4b] text-white hover:bg-[#ee2a2a]'
                    : isDark ? 'bg-[#77d0ff] text-white hover:bg-[#0099ff]' : 'bg-[#1e3a8a] text-white hover:bg-[#1e40af]'
              }`}
            >
              {isAnswered ? 'Далее' : 'Проверить'}
            </button>
          </div>
        </div>
      </div>

      {/* Detailed Modal Window */}
      {isDetailOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fadeIn">
          <div className={`max-w-xl w-full rounded-[2.5rem] p-8 shadow-2xl relative animate-zoomIn ${isDark ? 'bg-[#1a2b33] text-white border-2 border-[#37464f]' : 'bg-white text-gray-800'}`}>
            <button 
              onClick={() => setIsDetailOpen(false)} 
              className="absolute top-6 right-6 text-gray-400 hover:text-gray-600 text-2xl"
            >
              ✕
            </button>
            
            <div className="flex items-center gap-4 mb-6">
              <span className="text-4xl">👨‍🏫</span>
              <h2 className="text-2xl font-black uppercase tracking-tighter">Разбор задания</h2>
            </div>

            {detailLoading ? (
              <div className="py-12 flex flex-col items-center gap-4">
                <div className="w-10 h-10 border-4 border-[#1e3a8a] border-t-transparent rounded-full animate-spin"></div>
                <p className="font-bold opacity-60">Учитель думает...</p>
              </div>
            ) : detailedData && (
              <div className="space-y-6">
                <div className={`p-5 rounded-2xl ${isDark ? 'bg-white/5' : 'bg-blue-50'}`}>
                  <h4 className="text-xs font-black uppercase tracking-widest text-[#1899d6] mb-2">Почему так?</h4>
                  <p className="font-bold leading-relaxed">{detailedData.detail}</p>
                </div>
                
                <div className={`p-5 rounded-2xl border-2 border-dashed ${isDark ? 'border-[#37464f]' : 'border-orange-200 bg-orange-50/30'}`}>
                  <h4 className="text-xs font-black uppercase tracking-widest text-orange-500 mb-2">Похожий пример</h4>
                  <p className="font-bold italic">{detailedData.example}</p>
                </div>

                <button 
                  onClick={() => setIsDetailOpen(false)}
                  className={`w-full py-4 rounded-2xl font-black uppercase tracking-widest text-white transition-all duo-button-shadow ${isCorrect ? 'bg-[#1e3a8a]' : 'bg-[#1899d6]'}`}
                >
                  Понятно!
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      <style>{`
        @keyframes slideUp {
          from { transform: translateY(30px); opacity: 0; }
          to { transform: translateY(0); opacity: 1; }
        }
        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        @keyframes zoomIn {
          from { transform: scale(0.9); opacity: 0; }
          to { transform: scale(1); opacity: 1; }
        }
        .animate-slideUp { animation: slideUp 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275) forwards; }
        .animate-fadeIn { animation: fadeIn 0.3s ease-out forwards; }
        .animate-zoomIn { animation: zoomIn 0.3s cubic-bezier(0.34, 1.56, 0.64, 1) forwards; }
      `}</style>
    </div>
  );
};

export default Quiz;