import React from 'react';

interface IconProps {
  className?: string;
  color?: string;
}

// Fixed: Made children optional and allowed additional props to support spreading of IconProps which doesn't contain children
const BaseIcon = ({ children, className = "w-12 h-12" }: { children?: React.ReactNode, className?: string, [key: string]: any }) => (
  <svg 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="1.5" 
    strokeLinecap="round" 
    strokeLinejoin="round" 
    className={`${className} filter drop-shadow-sm`}
    style={{ filter: 'url(#hand-drawn-filter)' }}
  >
    <defs>
      <filter id="hand-drawn-filter">
        <feTurbulence type="fractalNoise" baseFrequency="0.05" numOctaves="2" result="noise" />
        <feDisplacementMap in="SourceGraphic" in2="noise" scale="1" />
      </filter>
    </defs>
    {children}
  </svg>
);

export const MenuIcon = (props: IconProps) => (
  <BaseIcon {...props}>
    <path d="M4 6h16M4 12h16M4 18h16" />
  </BaseIcon>
);

export const MathIcon = (props: IconProps) => (
  <BaseIcon {...props}>
    <path d="M12 5v14M5 12h14M16 16l3 3m0-3l-3 3M5 5l3 3m0-3L5 8" />
    <path d="M18 7h-4" />
  </BaseIcon>
);

export const RussianIcon = (props: IconProps) => (
  <BaseIcon {...props}>
    <path d="M4 20h16M7 16l3-10 3 10M8 12h4" />
    <path d="M16 6v10a2 2 0 0 0 2 2h2" />
  </BaseIcon>
);

export const ReadingIcon = (props: IconProps) => (
  <BaseIcon {...props}>
    <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20" />
    <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z" />
    <path d="M8 6h8M8 10h8M8 14h4" />
  </BaseIcon>
);

export const WorldIcon = (props: IconProps) => (
  <BaseIcon {...props}>
    <circle cx="12" cy="12" r="10" />
    <path d="M2 12h20M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z" />
  </BaseIcon>
);

export const HistoryIcon = (props: IconProps) => (
  <BaseIcon {...props}>
    <path d="M12 22v-5M9 22v-2M15 22v-2" />
    <path d="M18 17H6a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2z" />
    <path d="M8 7h8M8 11h8" />
  </BaseIcon>
);

export const BiologyIcon = (props: IconProps) => (
  <BaseIcon {...props}>
    <path d="M11 20a7 7 0 0 1-7-7c0-3.87 3.13-7 7-7s7 3.13 7 7c0 3.87-3.13 7-7 7z" />
    <path d="M11 13a4 4 0 1 0 0-8 4 4 0 0 0 0 8z" />
    <path d="M11 13v7M17 13h4M3 13h4" />
  </BaseIcon>
);

export const GeographyIcon = (props: IconProps) => (
  <BaseIcon {...props}>
    <path d="m3 7 6-3 6 3 6-3v13l-6 3-6-3-6 3V7zM9 4v13M15 7v13" />
  </BaseIcon>
);

export const PhysicsIcon = (props: IconProps) => (
  <BaseIcon {...props}>
    <path d="M13 2 3 14h9l-1 8 10-12h-9l1-8z" />
  </BaseIcon>
);

export const ChemistryIcon = (props: IconProps) => (
  <BaseIcon {...props}>
    <path d="M9 3h6M10 3v6l-4 8a2 2 0 0 0 2 3h8a2 2 0 0 0 2-3l-4-8V3" />
    <path d="M8.5 13h7" />
  </BaseIcon>
);

export const GeometryIcon = (props: IconProps) => (
  <BaseIcon {...props}>
    <path d="m3 21 18-18v18H3z" />
    <path d="M11 13a2 2 0 1 0 0-4 2 2 0 0 0 0 4z" />
  </BaseIcon>
);

export const OwlIcon = ({ className = "w-24 h-24" }: { className?: string }) => (
  <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
    <circle cx="50" cy="55" r="35" fill="#1e3a8a" />
    <path d="M30 35C30 35 35 25 50 25C65 25 70 35 70 35" stroke="#1e40af" strokeWidth="3" strokeLinecap="round" />
    <circle cx="38" cy="45" r="8" fill="white" />
    <circle cx="62" cy="45" r="8" fill="white" />
    <circle cx="38" cy="45" r="3" fill="#131F24" />
    <circle cx="62" cy="45" r="3" fill="#131F24" />
    <path d="M46 55L50 62L54 55H46Z" fill="#FFC800" stroke="#E5B500" strokeWidth="1" />
    <path d="M30 65C30 65 35 75 50 75C65 75 70 65 70 65" stroke="#1e40af" strokeWidth="2" strokeLinecap="round" />
  </svg>
);