import React, { useState } from 'react';
import { UserProfile, Subject, ThemeType, DictionaryTerm, Question } from '../types';
import { SUBJECTS, BADGES } from '../constants';
import * as Icons from './HandDrawnIcons';
import { geminiService } from '../services/geminiService';

interface DashboardProps {
  user: UserProfile;
  onSelectSubject: (subject: Subject) => void;
  onThemeChange: (theme: ThemeType) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ user, onSelectSubject, onThemeChange }) => {
  const [activeTab, setActiveTab] = useState('home');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [selectedTerm, setSelectedTerm] = useState<DictionaryTerm | null>(null);
  const [termData, setTermData] = useState<{ explanation: string, miniQuestion: Question } | null>(null);
  const [termLoading, setTermLoading] = useState(false);
  const [miniQuizState, setMiniQuizState] = useState<{ selected: number | null, isAnswered: boolean }>({ selected: null, isAnswered: false });

  const isDark = user.theme !== 'light';

  const filteredSubjects = SUBJECTS.filter(
    s => user.grade >= s.minGrade && user.grade <= s.maxGrade
  );

  const nextBadge = BADGES.find(b => user.xp < b.xpReq) || BADGES[BADGES.length - 1];
  const badgeProgress = Math.min(100, (user.xp / nextBadge.xpReq) * 100);

  const borderClasses = {
    light: 'border-gray-100',
    dark: 'border-[#37464f]',
    ocean: 'border-[#144d58]',
    sunset: 'border-[#4d213d]'
  };

  const cardClasses = isDark ? 'bg-[#1a2b33] border-[#37464f]' : 'bg-white border-gray-200';

  const getIcon = (iconName: string, colorClass: string) => {
    const iconKey = (iconName.charAt(0).toUpperCase() + iconName.slice(1) + 'Icon') as keyof typeof Icons;
    const IconComp = (Icons as any)[iconKey] as React.ComponentType<{ className?: string }>;
    if (!IconComp) return <span>📚</span>;
    return <IconComp className="w-12 h-12 text-white" />;
  };

  const handleTermClick = async (term: DictionaryTerm) => {
    setSelectedTerm(term);
    setTermLoading(true);
    setTermData(null);
    setMiniQuizState({ selected: null, isAnswered: false });
    try {
      const data = await geminiService.getTopicRefresh(term);
      setTermData(data);
    } catch (err) {
      console.error(err);
    } finally {
      setTermLoading(false);
    }
  };

  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
    setIsMobileMenuOpen(false);
  };

  const renderHome = () => (
    <>
      <header className="mb-12">
        <h1 className="text-3xl font-black">Твой путь обучения, {user.name}!</h1>
        <p className="opacity-60 font-bold">Класс: {user.grade}. Пройдено уроков: {user.totalLessons || 0}.</p>
      </header>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredSubjects.map((subject) => {
          const level = user.subjectLevels?.[subject.id] || 1;
          return (
            <button
              key={subject.id}
              onClick={() => onSelectSubject(subject)}
              className={`group relative flex flex-col items-center p-8 rounded-[2.5rem] border-b-8 border-2 transition-all active:border-b-0 active:translate-y-2 ${cardClasses} hover:border-gray-300`}
            >
              <div className={`w-24 h-24 ${subject.color} rounded-3xl flex items-center justify-center mb-6 group-hover:scale-110 group-hover:rotate-3 transition-all shadow-xl`}>
                {getIcon(subject.icon, subject.color)}
              </div>
              <h3 className="font-black uppercase tracking-widest text-lg">{subject.name}</h3>
              <div className="mt-2 flex items-center gap-1 text-xs font-black text-yellow-500">
                ⭐ Уровень: {level}
              </div>
              <div className="mt-6 w-full h-3 bg-black/10 rounded-full overflow-hidden">
                <div className="h-full bg-yellow-400 rounded-full shadow-[0_0_12px_rgba(250,204,21,0.6)]" style={{ width: `${(level/10)*100}%` }}></div>
              </div>
            </button>
          );
        })}
      </div>
    </>
  );

  const renderAchievements = () => (
    <div className="space-y-8 animate-fadeIn">
      <h1 className="text-3xl font-black">Твои Достижения</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className={`p-8 rounded-[2.5rem] border-2 ${cardClasses} flex items-center gap-6 shadow-sm`}>
          <div className="text-5xl">🔥</div>
          <div>
            <div className="text-3xl font-black">{user.streak} дн.</div>
            <div className="text-sm opacity-60 font-bold uppercase tracking-widest">Ударный режим</div>
          </div>
        </div>
        <div className={`p-8 rounded-[2.5rem] border-2 ${cardClasses} flex items-center gap-6 shadow-sm`}>
          <div className="text-5xl">🎓</div>
          <div>
            <div className="text-3xl font-black">{user.totalLessons || 0}</div>
            <div className="text-sm opacity-60 font-bold uppercase tracking-widest">Пройдено уроков</div>
          </div>
        </div>
      </div>
      <div className={`p-10 rounded-[3rem] border-2 ${cardClasses} shadow-sm`}>
        <h2 className="text-xl font-black mb-8 uppercase tracking-[0.2em] text-center">Коллекция медалей</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
          {BADGES.map((badge) => {
            const isUnlocked = user.xp >= badge.xpReq;
            return (
              <div key={badge.id} className={`flex items-center gap-6 p-6 rounded-3xl border-2 transition-all ${isUnlocked ? 'border-[#1e3a8a] bg-[#1e3a8a]/10 scale-105 shadow-md' : 'opacity-30 grayscale border-dashed border-gray-300'}`}>
                <div className="text-6xl">{badge.icon}</div>
                <div>
                  <h3 className="font-black text-xl">{badge.name}</h3>
                  <p className="text-xs font-bold opacity-70 mt-1">{badge.description}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );

  const renderDictionary = () => (
    <div className="space-y-8 animate-fadeIn">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-black">Мой Словарь</h1>
        <div className="px-6 py-3 rounded-2xl bg-blue-500/10 text-blue-500 font-black text-sm uppercase tracking-widest">
          {user.vocabulary?.length || 0} слов
        </div>
      </div>
      {!user.vocabulary || user.vocabulary.length === 0 ? (
        <div className={`p-20 rounded-[3rem] border-2 border-dashed ${borderClasses[user.theme]} text-center opacity-60`}>
          <div className="text-8xl mb-6">📖</div>
          <h2 className="text-2xl font-black uppercase">Словарь пуст</h2>
          <p className="font-bold mt-4">Изучай новые предметы, чтобы наполнять свою копилку знаний!</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-6">
          {[...user.vocabulary].reverse().map((item, idx) => (
            <button 
              key={idx} 
              onClick={() => handleTermClick(item)}
              className={`p-8 rounded-[2rem] border-2 ${cardClasses} hover:translate-x-2 transition-transform shadow-sm group text-left w-full`}
            >
              <div className="flex items-center justify-between mb-2">
                 <h3 className="text-2xl font-black text-[#1899d6] group-hover:text-[#1e3a8a] transition-colors">{item.term}</h3>
                 <span className="text-xl opacity-0 group-hover:opacity-100 transition-opacity">🚀</span>
              </div>
              <p className="font-bold opacity-80 text-lg leading-relaxed">{item.definition}</p>
            </button>
          ))}
        </div>
      )}
    </div>
  );

  const renderSettings = () => (
    <div className="space-y-8 animate-fadeIn">
      <h1 className="text-3xl font-black">Профиль и Настройки</h1>
      <div className={`p-10 rounded-[3rem] border-2 ${cardClasses} shadow-sm`}>
        <h2 className="text-xl font-black mb-8 uppercase tracking-widest text-center text-[#1e3a8a]">{user.name}</h2>
        <div className="flex flex-col items-center mb-10">
          <Icons.OwlIcon className="w-24 h-24 mb-4" />
          <div className="flex items-center gap-6">
            <div className="text-center">
              <div className="text-2xl font-black">{user.grade}</div>
              <div className="text-[10px] uppercase font-black opacity-50 tracking-widest">Класс</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-black">{user.xp}</div>
              <div className="text-[10px] uppercase font-black opacity-50 tracking-widest">Опыт (XP)</div>
            </div>
          </div>
        </div>

        <h2 className="text-xl font-black mb-8 uppercase tracking-widest text-center">Выбор темы</h2>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-6">
          {(['light', 'dark', 'ocean', 'sunset'] as ThemeType[]).map((t) => (
            <button
              key={t}
              onClick={() => onThemeChange(t)}
              className={`p-6 rounded-3xl border-2 transition-all flex flex-col items-center gap-4 ${
                user.theme === t 
                  ? 'border-[#1899d6] bg-[#ddf4ff] text-[#1899d6] scale-105 shadow-md' 
                  : isDark ? 'border-[#37464f] hover:bg-white/5' : 'border-gray-200 hover:bg-gray-50'
              }`}
            >
              <div className={`w-14 h-14 rounded-2xl ${t === 'light' ? 'bg-[#1e3a8a]' : t === 'dark' ? 'bg-[#77d0ff]' : t === 'ocean' ? 'bg-[#00cd9c]' : 'bg-[#ff4b4b]'} shadow-lg`} />
              <span className="font-black uppercase text-xs tracking-tighter">
                {t === 'light' ? 'Классика' : t === 'dark' ? 'Ночь' : t === 'ocean' ? 'Океан' : 'Закат'}
              </span>
            </button>
          ))}
        </div>
      </div>
      <div className="text-center">
        <button 
          onClick={() => { localStorage.clear(); window.location.reload(); }}
          className="px-8 py-4 rounded-2xl border-2 border-red-500 text-red-500 font-black uppercase tracking-widest text-sm hover:bg-red-500 hover:text-white transition-all shadow-sm"
        >
          Удалить аккаунт и прогресс
        </button>
      </div>
    </div>
  );

  return (
    <div className={`min-h-screen ${isDark ? (user.theme === 'dark' ? 'bg-[#131f24]' : user.theme === 'ocean' ? 'bg-[#0a2e36]' : 'bg-[#2a1122]') : 'bg-white'} ${isDark ? 'text-white' : 'text-gray-800'} pb-24 lg:pl-64 theme-transition`}>
      
      {/* Mobile Bar */}
      <div className={`lg:hidden flex items-center justify-between p-4 border-b-2 ${borderClasses[user.theme]} sticky top-0 ${isDark ? 'bg-[#131f24]/90' : 'bg-white/90'} backdrop-blur-md z-30 transition-all`}>
        <button 
          onClick={() => setIsMobileMenuOpen(true)} 
          className="p-2 hover:bg-black/5 rounded-xl transition-colors"
          aria-label="Открыть меню"
        >
          <Icons.MenuIcon className={`w-8 h-8 ${isDark ? 'text-white' : 'text-gray-600'}`} />
        </button>
        <div className="flex items-center gap-2">
          <Icons.OwlIcon className="w-10 h-10" />
          <span className="font-black text-[#1e3a8a] text-2xl tracking-tighter">EduLingo</span>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1 font-black text-orange-500 text-sm">🔥 {user.streak}</div>
          <div className="flex items-center gap-1 font-black text-blue-500 text-sm">💎 {user.xp}</div>
        </div>
      </div>

      {/* Mobile Sidebar Overlay */}
      {isMobileMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div className="fixed inset-0 bg-black/40 backdrop-blur-sm animate-fadeIn" onClick={() => setIsMobileMenuOpen(false)} />
          <aside className={`relative w-80 max-w-[85vw] h-full shadow-2xl animate-slideRight flex flex-col p-8 border-r-2 ${borderClasses[user.theme]} ${isDark ? (user.theme === 'dark' ? 'bg-[#131f24]' : user.theme === 'ocean' ? 'bg-[#0a2e36]' : 'bg-[#2a1122]') : 'bg-white'}`}>
            <div className="mb-12 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Icons.OwlIcon className="w-10 h-10" />
                <span className="font-black text-[#1e3a8a] text-2xl tracking-tighter">EduLingo</span>
              </div>
              <button onClick={() => setIsMobileMenuOpen(false)} className="text-3xl font-bold opacity-40">×</button>
            </div>
            
            <nav className="space-y-4 flex-1">
              <NavItem active={activeTab === 'home'} onClick={() => handleTabChange('home')} icon="🏠" label="Уроки" theme={user.theme} />
              <NavItem active={activeTab === 'achievements'} onClick={() => handleTabChange('achievements')} icon="🏆" label="Успехи" theme={user.theme} />
              <NavItem active={activeTab === 'dictionary'} onClick={() => handleTabChange('dictionary')} icon="📖" label="Слова" theme={user.theme} />
              <NavItem active={activeTab === 'profile'} onClick={() => handleTabChange('profile')} icon="👤" label="Я" theme={user.theme} />
            </nav>

            <div className="mt-auto pt-8 border-t-2 border-inherit space-y-4">
              <div className={`p-6 rounded-[2rem] border-2 ${cardClasses} shadow-sm`}>
                <div className="flex items-center justify-between mb-4">
                  <span className="font-black text-[10px] opacity-60 uppercase tracking-widest">Цель</span>
                  <span className="text-2xl animate-bounce">{nextBadge.icon}</span>
                </div>
                <div className="h-3 bg-black/5 rounded-full overflow-hidden">
                  <div className={`h-full ${user.theme === 'light' ? 'bg-[#1e3a8a]' : user.theme === 'dark' ? 'bg-[#77d0ff]' : user.theme === 'ocean' ? 'bg-[#00cd9c]' : 'bg-[#ff4b4b]'} transition-all duration-1000`} style={{ width: `${badgeProgress}%` }} />
                </div>
                <p className="mt-3 text-[10px] font-black opacity-60 uppercase tracking-tighter">{nextBadge.name}</p>
              </div>
            </div>
          </aside>
        </div>
      )}

      {/* Content Area */}
      <div className="max-w-4xl mx-auto p-6 lg:p-12">
        {activeTab === 'home' && renderHome()}
        {activeTab === 'achievements' && renderAchievements()}
        {activeTab === 'dictionary' && renderDictionary()}
        {activeTab === 'profile' && renderSettings()}
      </div>

      {/* Sidebar Desktop */}
      <aside className={`hidden lg:flex flex-col fixed left-0 top-0 bottom-0 w-64 border-r-2 ${borderClasses[user.theme]} p-8 theme-transition z-40`}>
        <div className="mb-16 flex items-center gap-3">
          <Icons.OwlIcon className="w-12 h-12" />
          <span className="font-black text-[#1e3a8a] text-3xl tracking-tighter">EduLingo</span>
        </div>
        <nav className="space-y-6 flex-1">
          <NavItem active={activeTab === 'home'} onClick={() => setActiveTab('home')} icon="🏠" label="Уроки" theme={user.theme} />
          <NavItem active={activeTab === 'achievements'} onClick={() => setActiveTab('achievements')} icon="🏆" label="Успехи" theme={user.theme} />
          <NavItem active={activeTab === 'dictionary'} onClick={() => setActiveTab('dictionary')} icon="📖" label="Слова" theme={user.theme} />
          <NavItem active={activeTab === 'profile'} onClick={() => setActiveTab('profile')} icon="👤" label="Я" theme={user.theme} />
        </nav>
        
        <div className="mt-auto pt-8 border-t-2 border-inherit">
          <div className={`p-6 rounded-[2rem] border-2 ${cardClasses} shadow-sm`}>
            <div className="flex items-center justify-between mb-4">
              <span className="font-black text-[10px] opacity-60 uppercase tracking-widest">Цель</span>
              <span className="text-2xl animate-bounce">{nextBadge.icon}</span>
            </div>
            <div className="h-3 bg-black/5 rounded-full overflow-hidden">
              <div className={`h-full ${user.theme === 'light' ? 'bg-[#1e3a8a]' : user.theme === 'dark' ? 'bg-[#77d0ff]' : user.theme === 'ocean' ? 'bg-[#00cd9c]' : 'bg-[#ff4b4b]'} transition-all duration-1000`} style={{ width: `${badgeProgress}%` }} />
            </div>
            <p className="mt-3 text-[10px] font-black opacity-60 uppercase tracking-tighter">{nextBadge.name}</p>
          </div>
        </div>
      </aside>

      {/* Top Stats Desktop */}
      <div className="hidden lg:flex fixed top-0 right-0 p-8 gap-6 items-center z-50">
         <div className={`flex items-center gap-3 px-6 py-3 rounded-2xl border-2 ${borderClasses[user.theme]} font-black text-orange-500 bg-white/10 backdrop-blur-xl shadow-sm transition-transform hover:scale-105 cursor-default`}>
           <span>🔥</span> {user.streak}
         </div>
         <div className={`flex items-center gap-3 px-6 py-3 rounded-2xl border-2 ${borderClasses[user.theme]} font-black text-blue-500 bg-white/10 backdrop-blur-xl shadow-sm transition-transform hover:scale-105 cursor-default`}>
           <span>💎</span> {user.xp}
         </div>
      </div>

      {/* Term Detail Modal */}
      {selectedTerm && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/60 backdrop-blur-md animate-fadeIn">
          <div className={`max-w-2xl w-full rounded-[3rem] p-8 lg:p-12 shadow-2xl relative animate-zoomIn max-h-[90vh] overflow-y-auto ${isDark ? 'bg-[#1a2b33] text-white border-2 border-[#37464f]' : 'bg-white text-gray-800'}`}>
             <button onClick={() => setSelectedTerm(null)} className="absolute top-8 right-8 text-3xl font-bold opacity-40 hover:opacity-100 transition-opacity">✕</button>
             
             {termLoading ? (
               <div className="py-20 flex flex-col items-center gap-6">
                 <div className="w-16 h-16 border-4 border-[#1e3a8a] border-t-transparent rounded-full animate-spin"></div>
                 <h3 className="text-xl font-black uppercase tracking-widest opacity-60">Загружаем знания...</h3>
               </div>
             ) : termData && (
               <div className="space-y-10">
                 <header className="text-center">
                    <span className="text-xs font-black uppercase tracking-[0.3em] text-[#1e3a8a] mb-2 block">Повторение темы</span>
                    <h2 className="text-4xl font-black mb-4">{selectedTerm.term}</h2>
                    <div className="w-20 h-1 bg-[#1e3a8a] mx-auto rounded-full"></div>
                 </header>

                 <div className={`p-8 rounded-3xl border-2 ${isDark ? 'bg-white/5 border-[#37464f]' : 'bg-blue-50 border-blue-100'}`}>
                    <h4 className="text-sm font-black uppercase mb-4 text-[#1899d6]">Подробное объяснение</h4>
                    <p className="text-xl font-bold leading-relaxed">{termData.explanation}</p>
                 </div>

                 <div className="space-y-6">
                    <div className="flex items-center gap-4 mb-2">
                       <span className="text-2xl">📝</span>
                       <h4 className="text-xl font-black">Проверь себя:</h4>
                    </div>
                    <p className="text-lg font-bold">{termData.miniQuestion.text}</p>
                    <div className="grid grid-cols-1 gap-3">
                      {termData.miniQuestion.options.map((opt, idx) => (
                        <button
                          key={idx}
                          disabled={miniQuizState.isAnswered}
                          onClick={() => setMiniQuizState({ selected: idx, isAnswered: true })}
                          className={`p-5 rounded-2xl border-2 text-left font-black transition-all ${
                            miniQuizState.selected === idx
                              ? idx === termData.miniQuestion.correctIndex
                                ? 'bg-[#1e3a8a] border-[#1e3a8a] text-white'
                                : 'bg-[#ff4b4b] border-[#ff4b4b] text-white'
                              : isDark ? 'border-[#37464f] hover:bg-white/5' : 'border-gray-200 hover:bg-gray-50'
                          } ${miniQuizState.isAnswered && idx === termData.miniQuestion.correctIndex ? 'border-[#1e3a8a] text-[#1e3a8a] bg-[#1e3a8a]/10' : ''}`}
                        >
                          {opt}
                        </button>
                      ))}
                    </div>
                    {miniQuizState.isAnswered && (
                      <div className={`p-6 rounded-2xl animate-slideUp ${miniQuizState.selected === termData.miniQuestion.correctIndex ? 'bg-[#dbeafe] text-[#1e3a8a]' : 'bg-[#ffdfe0] text-[#ee2a2a]'}`}>
                        <p className="font-black mb-1">{miniQuizState.selected === termData.miniQuestion.correctIndex ? 'Верно!' : 'Не совсем...'}</p>
                        <p className="text-sm font-bold opacity-80">{termData.miniQuestion.explanation}</p>
                      </div>
                    )}
                 </div>

                 <button 
                  onClick={() => setSelectedTerm(null)}
                  className="w-full py-5 rounded-3xl bg-[#1e3a8a] text-white font-black uppercase tracking-widest text-xl duo-button-shadow hover:bg-[#1e40af] transition-all"
                 >
                   Я все понял!
                 </button>
               </div>
             )}
          </div>
        </div>
      )}

      <style>{`
        @keyframes slideRight {
          from { transform: translateX(-100%); }
          to { transform: translateX(0); }
        }
        @keyframes slideUp {
          from { transform: translateY(20px); opacity: 0; }
          to { transform: translateY(0); opacity: 1; }
        }
        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        @keyframes zoomIn {
          from { transform: scale(0.95); opacity: 0; }
          to { transform: scale(1); opacity: 1; }
        }
        .animate-slideRight { animation: slideRight 0.3s ease-out forwards; }
        .animate-slideUp { animation: slideUp 0.3s ease-out forwards; }
        .animate-fadeIn { animation: fadeIn 0.2s ease-out forwards; }
        .animate-zoomIn { animation: zoomIn 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275) forwards; }
      `}</style>
    </div>
  );
};

const NavItem = ({ icon, label, active = false, onClick, theme }: { icon: string, label: string, active?: boolean, onClick?: () => void, theme: ThemeType }) => {
  const isDark = theme !== 'light';
  return (
    <button onClick={onClick} className={`flex items-center gap-4 w-full px-5 py-4 rounded-2xl font-black uppercase tracking-[0.15em] transition-all border-2 ${
      active ? (isDark ? 'bg-[#37464f] border-[#77d0ff] text-[#77d0ff] shadow-md' : 'bg-[#ddf4ff] text-[#1899d6] border-[#84d8ff] shadow-md') : `border-transparent opacity-50 hover:opacity-100 ${isDark ? 'hover:bg-white/5' : 'hover:bg-gray-50'}`
    }`}>
      <span className="text-2xl">{icon}</span>
      <span className="text-xs">{label}</span>
    </button>
  );
};

export default Dashboard;