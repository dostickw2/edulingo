import React, { useState } from 'react';
import { Grade, UserProfile } from '../types';
import { OwlIcon } from './HandDrawnIcons';

interface OnboardingProps {
  onComplete: (profile: UserProfile) => void;
}

const Onboarding: React.FC<OnboardingProps> = ({ onComplete }) => {
  const [name, setName] = useState('');
  const [grade, setGrade] = useState<Grade>(1);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    onComplete({
      name,
      grade,
      xp: 0,
      streak: 0,
      unlockedBadges: [],
    } as any);
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-[#f7f7f7]">
      <div className="max-w-md w-full text-center space-y-12">
        <div className="flex flex-col items-center animate-fadeIn">
          <OwlIcon className="w-32 h-32 mb-6 drop-shadow-xl animate-bounce" />
          <h1 className="text-5xl font-black text-[#1e3a8a] tracking-tighter">EduLingo</h1>
          <p className="text-gray-500 text-xl mt-4 font-bold max-w-xs mx-auto">Привет! Я помогу тебе стать отличником. Как тебя зовут?</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-8 bg-white p-10 rounded-[3rem] shadow-2xl border-b-8 border-gray-200">
          <div className="text-left">
            <label className="block text-gray-400 font-black mb-3 uppercase text-[10px] tracking-[0.2em] ml-2">Твое имя</label>
            <input
              type="text"
              required
              className="w-full px-6 py-4 rounded-2xl border-2 border-gray-100 focus:border-[#1e3a8a] focus:bg-white bg-gray-50 focus:outline-none transition-all font-bold text-lg text-gray-900"
              placeholder="Введите имя..."
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>

          <div className="text-left">
            <label className="block text-gray-400 font-black mb-3 uppercase text-[10px] tracking-[0.2em] ml-2">Твой класс</label>
            <div className="grid grid-cols-4 sm:grid-cols-6 gap-3">
              {Array.from({ length: 11 }, (_, i) => (i + 1) as Grade).map((g) => (
                <button
                  key={g}
                  type="button"
                  onClick={() => setGrade(g)}
                  className={`h-12 w-full rounded-xl border-2 font-black transition-all ${
                    grade === g 
                      ? 'bg-[#1e3a8a] border-[#1e3a8a] text-white shadow-lg scale-110' 
                      : 'border-gray-100 text-gray-300 hover:border-gray-200 hover:text-gray-400'
                  }`}
                >
                  {g}
                </button>
              ))}
            </div>
          </div>

          <button
            type="submit"
            className="w-full bg-[#1e3a8a] hover:bg-[#1e40af] text-white font-black py-5 rounded-2xl text-xl uppercase tracking-widest duo-button-shadow transition-all shadow-xl"
          >
            Начать путь
          </button>
        </form>
      </div>
    </div>
  );
};

export default Onboarding;