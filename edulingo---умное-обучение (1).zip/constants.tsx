
import { Subject } from './types';

export const SUBJECTS: Subject[] = [
  { id: 'math', name: 'Математика', icon: 'math', color: 'bg-blue-500', minGrade: 1, maxGrade: 11 },
  { id: 'russian', name: 'Русский язык', icon: 'russian', color: 'bg-yellow-500', minGrade: 1, maxGrade: 11 },
  { id: 'reading', name: 'Чтение', icon: 'reading', color: 'bg-orange-400', minGrade: 1, maxGrade: 4 },
  { id: 'world', name: 'Окружающий мир', icon: 'world', color: 'bg-green-500', minGrade: 1, maxGrade: 4 },
  { id: 'history', name: 'История', icon: 'history', color: 'bg-red-500', minGrade: 5, maxGrade: 11 },
  { id: 'biology', name: 'Биология', icon: 'biology', color: 'bg-green-600', minGrade: 5, maxGrade: 11 },
  { id: 'geography', name: 'География', icon: 'geography', color: 'bg-blue-400', minGrade: 5, maxGrade: 11 },
  { id: 'physics', name: 'Физика', icon: 'physics', color: 'bg-purple-500', minGrade: 7, maxGrade: 11 },
  { id: 'chemistry', name: 'Химия', icon: 'chemistry', color: 'bg-pink-500', minGrade: 8, maxGrade: 11 },
  { id: 'geometry', name: 'Геометрия', icon: 'geometry', color: 'bg-cyan-500', minGrade: 7, maxGrade: 11 },
];

export const BADGES = [
  { id: 'starter', name: 'Первые шаги', icon: '🌱', xpReq: 100, description: 'Набери свои первые 100 XP' },
  { id: 'scholar', name: 'Ученик', icon: '📖', xpReq: 500, description: 'Серьезный подход к учебе (500 XP)' },
  { id: 'brainiac', name: 'Умник', icon: '🧠', xpReq: 1500, description: 'Твой мозг работает на полную! (1500 XP)' },
  { id: 'master', name: 'Мастер', icon: '🎓', xpReq: 5000, description: 'Легендарный уровень знаний (5000 XP)' },
];
