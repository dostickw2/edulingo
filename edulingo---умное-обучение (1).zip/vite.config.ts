
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  // 'base' установлен в './', чтобы ссылки на файлы в index.html были относительными.
  // Это позволяет сайту работать на GitHub Pages в любой подпапке.
  base: './',
  define: {
    // Пробрасываем API_KEY в браузерную среду
    'process.env.API_KEY': JSON.stringify(process.env.API_KEY)
  },
  build: {
    outDir: 'dist',
  }
});
