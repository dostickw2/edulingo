import React, { useState, useEffect } from 'react';
import { UserProfile, Lesson, Subject, ThemeType, DictionaryTerm } from './types';
import Onboarding from './components/Onboarding';
import Dashboard from './components/Dashboard';
import Quiz from './components/Quiz';
import { geminiService } from './services/geminiService';
import { SUBJECTS } from './constants';
import { OwlIcon } from './components/HandDrawnIcons';

enum AppView {
  ONBOARDING,
  DASHBOARD,
  LESSON,
  LOADING
}

const App: React.FC = () => {
  const [view, setView] = useState<AppView>(AppView.ONBOARDING);
  const [user, setUser] = useState<UserProfile | null>(null);
  const [currentLesson, setCurrentLesson] = useState<Lesson | null>(null);
  const [loadingMsg, setLoadingMsg] = useState('Загружаем учебный план...');

  useEffect(() => {
    if (user?.theme) {
      document.body.className = `theme-${user.theme}`;
    } else {
      document.body.className = 'theme-light';
    }
  }, [user?.theme]);

  useEffect(() => {
    const saved = localStorage.getItem('edulingo_user');
    if (saved) {
      const parsed = JSON.parse(saved);
      if (!parsed.subjectLevels) parsed.subjectLevels = {};
      if (!parsed.vocabulary) parsed.vocabulary = [];
      if (!parsed.totalLessons) parsed.totalLessons = 0;
      setUser(parsed);
      setView(AppView.DASHBOARD);
    }
  }, []);

  const handleOnboardingComplete = (profile: any) => {
    const fullProfile: UserProfile = { 
      ...profile, 
      theme: 'light' as ThemeType,
      subjectLevels: {},
      vocabulary: [],
      totalLessons: 0,
      xp: 0,
      streak: 1,
      unlockedBadges: []
    };
    setUser(fullProfile);
    localStorage.setItem('edulingo_user', JSON.stringify(fullProfile));
    setView(AppView.DASHBOARD);
  };

  const handleThemeChange = (newTheme: ThemeType) => {
    if (!user) return;
    const updated = { ...user, theme: newTheme };
    setUser(updated);
    localStorage.setItem('edulingo_user', JSON.stringify(updated));
  };

  const handleSelectSubject = async (subject: Subject) => {
    if (!user) return;
    setView(AppView.LOADING);
    const currentLevel = user.subjectLevels?.[subject.id] || 1;
    setLoadingMsg(`Готовим урок по предмету: ${subject.name} (Уровень ${currentLevel})...`);
    
    try {
      const lesson = await geminiService.generateLesson(subject.name, user.grade, currentLevel);
      setCurrentLesson(lesson);
      setView(AppView.LESSON);
    } catch (err) {
      console.error(err);
      alert('Ой! Не удалось загрузить урок. Попробуй еще раз.');
      setView(AppView.DASHBOARD);
    }
  };

  const handleLessonFinish = (earnedXp: number) => {
    if (!user || !currentLesson) return;
    
    const subjectEntry = SUBJECTS.find(s => s.name === currentLesson.subject);
    const subjectId = subjectEntry?.id || 'math';

    const currentLevel = user.subjectLevels?.[subjectId] || 1;
    const newSubjectLevels = { ...user.subjectLevels, [subjectId]: Math.min(10, currentLevel + 1) };
    
    const newVocab = [...(user.vocabulary || [])];
    currentLesson.keyTerms.forEach(newTerm => {
      if (!newVocab.some(v => v.term.toLowerCase() === newTerm.term.toLowerCase())) {
        newVocab.push(newTerm);
      }
    });

    const updatedUser: UserProfile = {
      ...user,
      xp: user.xp + earnedXp,
      streak: user.streak, // В реальном приложении здесь была бы логика дат
      totalLessons: (user.totalLessons || 0) + 1,
      subjectLevels: newSubjectLevels,
      vocabulary: newVocab
    };
    
    setUser(updatedUser);
    localStorage.setItem('edulingo_user', JSON.stringify(updatedUser));
    setView(AppView.DASHBOARD);
    setCurrentLesson(null);
  };

  if (view === AppView.LOADING) {
    const isDark = user?.theme && user.theme !== 'light';
    return (
      <div className={`min-h-screen flex flex-col items-center justify-center p-6 ${isDark ? 'bg-[#131f24] text-white' : 'bg-white text-gray-800'}`}>
        <OwlIcon className="w-32 h-32 mb-8 animate-bounce drop-shadow-2xl" />
        <h2 className="text-3xl font-black text-center max-w-md leading-tight">{loadingMsg}</h2>
        <div className="mt-12 w-64 h-3 bg-gray-100 rounded-full overflow-hidden">
          <div className="h-full bg-[#1e3a8a] animate-[loading_1.5s_ease-in-out_infinite] shadow-[0_0_15px_rgba(30,58,138,0.5)]"></div>
        </div>
        <p className="mt-6 font-bold opacity-40 uppercase tracking-[0.3em] text-[10px]">Это не займет много времени</p>
        <style>{`
          @keyframes loading {
            0% { transform: translateX(-100%); }
            100% { transform: translateX(100%); }
          }
        `}</style>
      </div>
    );
  }

  if (view === AppView.ONBOARDING) {
    return <Onboarding onComplete={handleOnboardingComplete} />;
  }

  if (view === AppView.LESSON && currentLesson) {
    return (
      <Quiz 
        lesson={currentLesson} 
        onFinish={handleLessonFinish} 
        onClose={() => setView(AppView.DASHBOARD)} 
        theme={user?.theme || 'light'}
      />
    );
  }

  if (user) {
    return (
      <Dashboard 
        user={user} 
        onSelectSubject={handleSelectSubject} 
        onThemeChange={handleThemeChange}
      />
    );
  }

  return null;
};

export default App;