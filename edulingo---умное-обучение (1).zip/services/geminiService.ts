
import { GoogleGenAI, Type } from "@google/genai";
import { Lesson, Grade, Question, DictionaryTerm } from "../types";

export class GeminiService {
  private ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  async generateLesson(subject: string, grade: Grade, level: number = 1): Promise<Lesson> {
    const prompt = `Сгенерируй интерактивный урок по предмету "${subject}" для ученика ${grade} класса. 
    Текущий уровень сложности: ${level} (из 10). Чем выше уровень, тем глубже и сложнее должны быть вопросы.
    Урок должен состоять из названия, 5 вопросов с вариантами ответов и 3 ключевых терминов/правил урока для словаря. 
    Сложность должна строго соответствовать уровню ${level} и возрасту ${grade} класса.`;

    const response = await this.ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            questions: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  id: { type: Type.STRING },
                  text: { type: Type.STRING },
                  options: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING }
                  },
                  correctIndex: { type: Type.NUMBER },
                  explanation: { type: Type.STRING }
                },
                required: ["id", "text", "options", "correctIndex", "explanation"]
              }
            },
            keyTerms: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  term: { type: Type.STRING },
                  definition: { type: Type.STRING }
                },
                required: ["term", "definition"]
              }
            }
          },
          required: ["title", "questions", "keyTerms"]
        }
      }
    });

    const result = JSON.parse(response.text || "{}");
    return {
      ...result,
      subject
    };
  }

  async getDetailedExplanation(question: Question, userAnswer: string, isCorrect: boolean): Promise<{ detail: string, example: string }> {
    const prompt = `Пользователь ответил на вопрос: "${question.text}".
    Его ответ: "${userAnswer}".
    Это ${isCorrect ? 'верный' : 'неверный'} ответ.
    
    Сгенерируй подробное объяснение (почему так) и приведи один похожий пример для закрепления.
    Ответ должен быть в формате JSON с полями "detail" и "example". 
    Стиль: дружелюбный учитель, понятно для ребенка.`;

    const response = await this.ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            detail: { type: Type.STRING },
            example: { type: Type.STRING }
          },
          required: ["detail", "example"]
        }
      }
    });

    return JSON.parse(response.text || "{}");
  }

  async getTopicRefresh(term: DictionaryTerm): Promise<{ explanation: string, miniQuestion: Question }> {
    const prompt = `Пользователь хочет повторить термин: "${term.term}" (Базовое определение: ${term.definition}).
    1. Напиши расширенное и очень понятное объяснение этой темы (3-4 предложения).
    2. Сгенерируй один интересный проверочный вопрос (multiple choice) по этой теме.
    Ответ должен быть строго в формате JSON.`;

    const response = await this.ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            explanation: { type: Type.STRING },
            miniQuestion: {
              type: Type.OBJECT,
              properties: {
                id: { type: Type.STRING },
                text: { type: Type.STRING },
                options: { type: Type.ARRAY, items: { type: Type.STRING } },
                correctIndex: { type: Type.NUMBER },
                explanation: { type: Type.STRING }
              },
              required: ["id", "text", "options", "correctIndex", "explanation"]
            }
          },
          required: ["explanation", "miniQuestion"]
        }
      }
    });

    return JSON.parse(response.text || "{}");
  }
}

export const geminiService = new GeminiService();
